package com.example.farmerGateway;




import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

interface FarmerRepository extends JpaRepository<Farmer, Long> {
    Optional<Farmer> findByUsername(String username);

    @Query("SELECT f FROM Farmer f")
    List<Farmer> getAllFarmers();

      
    }

interface AdminRepository extends JpaRepository<Farmer, Long> {
    Optional<Admin> findByUsername(String username);

	Admin save(Admin admin);

   

      
    }

 interface CultivationRepository extends CrudRepository<Cultivation, Long> {
    // Additional methods if needed
}
