package com.example.farmerGateway;

import org.apache.catalina.startup.ClassLoaderFactory.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/farmers")
 class FarmerController {
    @Autowired
    private FarmerRepository farmerRepository;

    
    @PostMapping("/signup")
    public ResponseEntity<Farmer> signUp(@RequestBody Farmer farmer) {
        Farmer createdFarmer = farmerRepository.save(farmer);
        if (createdFarmer != null) {
            return new ResponseEntity<>(createdFarmer, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Farmer loginUser) {
        Optional<Farmer> userOptional = farmerRepository.findByUsername(loginUser.getUsername());
        if (userOptional.isPresent()) {
            Farmer user = userOptional.get();
            if (user.getPassword().equals(loginUser.getPassword())) {
                return ResponseEntity.ok("Login successful");
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
            }
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found");
        }
    }
    
    @GetMapping
    public List<Farmer> getAllFarmers() {
        return farmerRepository.getAllFarmers();
    }
    
}


@RestController
@RequestMapping("/crops")
 class CultivationController {
    @Autowired
    private CultivationRepository cultivationRepository;

    
    @PostMapping("/addcrop")
    public ResponseEntity<Cultivation> addCrop(@RequestBody Cultivation cultivation) {
        Cultivation createdCrop = cultivationRepository.save(cultivation);
        if (createdCrop != null) {
            return new ResponseEntity<>(createdCrop, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    // Other controller methods for CRUD operations
}

@RestController
@RequestMapping("/admin")
 class AdminController {
    @Autowired
    private AdminRepository adminRepository;

    
    @PostMapping("/signup")
    public ResponseEntity<Admin> signUp(@RequestBody Admin admin) {
        Admin createdAdmin = adminRepository.save(admin);
        if (createdAdmin != null) {
            return new ResponseEntity<>(createdAdmin, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Admin loginUser) {
        Optional<Admin> userOptional = adminRepository.findByUsername(loginUser.getUsername());
        if (userOptional.isPresent()) {
            Admin user = userOptional.get();
            if (user.getPassword().equals(loginUser.getPassword())) {
                return ResponseEntity.ok("Login successful");
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
            }
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found");
        }
    }
    
  
}
