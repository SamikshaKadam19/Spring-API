package com.example.farmerGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
